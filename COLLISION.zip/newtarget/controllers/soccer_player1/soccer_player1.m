function soccer_player1()
    TIME_STEP = 64;  % ms
    SPEED = 4.0;
    SEUIL = 0.1;

    wb_robot_init();

    left_motor = wb_robot_get_device('left wheel motor');
    right_motor = wb_robot_get_device('right wheel motor');
    wb_motor_set_position(left_motor, inf);
    wb_motor_set_position(right_motor, inf);

    sensor_names = {'ds_left', 'ds_front', 'ds_right', 'ds_back'};
    sensors = zeros(1, 4);
    for i = 1:4
        sensors(i) = wb_robot_get_device(sensor_names{i});
        wb_distance_sensor_enable(sensors(i), TIME_STEP);
    end

    while wb_robot_step(TIME_STEP) ~= -1
        left_val  = wb_distance_sensor_get_value(sensors(1));
        front_val = wb_distance_sensor_get_value(sensors(2));
        right_val = wb_distance_sensor_get_value(sensors(3));
        back_val  = wb_distance_sensor_get_value(sensors(4));

        % Logique d’évitement uniquement si nécessaire
        if front_val < SEUIL
            if left_val > right_val
                wb_motor_set_velocity(left_motor, -SPEED);
                wb_motor_set_velocity(right_motor, SPEED);
            else
                wb_motor_set_velocity(left_motor, SPEED);
                wb_motor_set_velocity(right_motor, -SPEED);
            end
        elseif left_val < SEUIL
            wb_motor_set_velocity(left_motor, SPEED);
            wb_motor_set_velocity(right_motor, -SPEED);
        elseif right_val < SEUIL
            wb_motor_set_velocity(left_motor, -SPEED);
            wb_motor_set_velocity(right_motor, SPEED);
        elseif back_val < SEUIL
            wb_motor_set_velocity(left_motor, SPEED / 2);
            wb_motor_set_velocity(right_motor, SPEED / 2);
        else
            % Aucun obstacle détecté – avancer tout droit
            wb_motor_set_velocity(left_motor, SPEED);
            wb_motor_set_velocity(right_motor, SPEED);
        end
    end

    wb_robot_cleanup();
end
